package gg.nulls.library;
import android.content.Context;
import org.json.*;
import java.io.*;
import java.util.*;

final class Repository {
    final Api api;
    final Context context;
    private final LinkedHashMap<String,JSONObject> scripts=new LinkedHashMap<>(),authors=new LinkedHashMap<>();
    private final HashMap<String,String> code=new HashMap<>();
    private int codeBytes=0;
    volatile long refreshed=0;
    volatile boolean indexing=false,cancelIndex=false;
    volatile String indexStatus="Код ещё не индексирован";
    private volatile String cacheAccount="";
    interface Progress { void update(String text); }
    Repository(Context c,Api a){context=c.getApplicationContext();api=a;readCache();}
    synchronized List<JSONObject> scripts(){return new ArrayList<>(scripts.values());}
    synchronized List<JSONObject> authors(){return new ArrayList<>(authors.values());}
    synchronized String code(String id){return code.get(id);}
    synchronized String handle(String id){JSONObject a=authors.get(id);return a==null?"":a.optString("username");}
    synchronized JSONObject author(String id){return authors.get(id);}
    void refresh(Progress progress)throws Exception{
        if(!api.authenticated())throw new IOException("Сначала войдите в аккаунт Null’s");
        String account=api.identity().getString("uuid");
        List<String> handles;String warning="";
        try{handles=Core.handles(Api.authorList());if(handles.isEmpty())throw new IOException("Пустой список авторов");}catch(IOException e){handles=new ArrayList<>(Arrays.asList(Core.FALLBACK));warning=" · резервный список";}
        LinkedHashMap<String,JSONObject> nextScripts=new LinkedHashMap<>(),nextAuthors=new LinkedHashMap<>();int fail=0,n=0;
        for(String handle:handles){progress.update("Авторы "+(++n)+" / "+handles.size()+warning);
            try{JSONObject author=Core.publicUser(api.request("GET","/users/@"+handle,null));Core.requireUuid(author.optString("uuid"));String id=author.getString("uuid");if(author.optString("username").isEmpty())author.put("username",handle);nextAuthors.put(id,author);
                JSONArray list=api.request("GET","/users/"+id+"/scripts",null).optJSONArray("scripts");if(list==null)throw new IOException("Нет списка скриптов");
                for(int i=0;i<list.length();i++){JSONObject s=Core.publicScript(list.getJSONObject(i));Core.requireUuid(s.optString("uuid"));if(s.optString("published_at").isEmpty())continue;s.put("author_uuid",id);if(s.optString("author_name").isEmpty())s.put("author_name",author.optString("name",handle));nextScripts.put(s.getString("uuid"),s);}
            }catch(Api.Failure e){if(e.status==401||e.status==429)throw e;fail++;}catch(Exception e){fail++;}
        }
        if(nextAuthors.isEmpty())throw new IOException("Не удалось получить авторов. Проверьте соединение.");
        if(!api.authenticated()||!account.equals(api.identity().optString("uuid")))throw new IOException("Аккаунт изменился. Обновите библиотеку заново.");
        synchronized(this){scripts.clear();scripts.putAll(nextScripts);authors.clear();authors.putAll(nextAuthors);code.clear();codeBytes=0;indexStatus="Код ещё не индексирован";refreshed=System.currentTimeMillis();writeCache();}
        progress.update(nextScripts.size()+" скриптов · "+nextAuthors.size()+" авторов"+(fail>0?" · недоступно: "+fail:""));
    }
    List<JSONObject> own()throws Exception{JSONObject me=api.identity();if(me==null)throw new IOException("Требуется вход");JSONArray list=api.request("GET","/users/"+me.getString("uuid")+"/scripts",null).getJSONArray("scripts");List<JSONObject> result=new ArrayList<>();for(int i=0;i<list.length();i++){JSONObject s=Core.publicScript(list.getJSONObject(i));s.put("author_uuid",me.getString("uuid"));if(s.optString("author_name").isEmpty())s.put("author_name",me.optString("name"));result.add(s);}return result;}
    String loadCode(String id)throws Exception{Core.requireUuid(id);String cached=code(id);if(cached!=null)return cached;JSONObject account=api.identity();if(account==null)throw new IOException("Требуется вход");String accountId=account.getString("uuid");String value=Core.clean(api.request("GET","/scripts/"+id+"/content",null).getString("content"));synchronized(this){if(api.authenticated()&&accountId.equals(api.identity().optString("uuid"))&&codeBytes+value.length()*2<=24*1024*1024){code.put(id,value);codeBytes+=value.length()*2;}}return value;}
    void index(Progress p)throws Exception{if(indexing)return;indexing=true;cancelIndex=false;List<JSONObject> list=scripts();int n=0,failed=0;try{for(JSONObject s:list){if(cancelIndex)break;try{loadCode(s.getString("uuid"));}catch(Api.Failure e){if(e.status==401||e.status==429)throw e;failed++;}catch(Exception e){failed++;}indexStatus="Код: "+(++n)+" / "+list.size()+(failed>0?" · недоступно: "+failed:"");p.update(indexStatus);Thread.sleep(120);}synchronized(this){indexStatus="Код: "+code.size()+" / "+list.size()+(cancelIndex?" · приостановлено":"")+(failed>0?" · недоступно: "+failed:"");}p.update(indexStatus);}finally{indexing=false;}}
    synchronized void forgetCode(String id){String previous=code.remove(id);if(previous!=null)codeBytes-=previous.length()*2;}
    synchronized void clearAccount(){cancelIndex=true;code.clear();codeBytes=0;indexStatus="Код ещё не индексирован";cacheAccount="";scripts.clear();authors.clear();refreshed=0;File file=new File(context.getFilesDir(),"public-catalog.json");if(file.exists())file.delete();}
    synchronized void bindAccount(String id){if(!cacheAccount.isEmpty()&&!cacheAccount.equals(id))clearAccount();cacheAccount=id;}
    private synchronized void readCache(){File file=new File(context.getFilesDir(),"public-catalog.json");try(FileInputStream in=new FileInputStream(file)){JSONObject o=new JSONObject(Api.read(in,8*1024*1024));cacheAccount=o.optString("account");JSONArray a=o.getJSONArray("authors"),s=o.getJSONArray("scripts");for(int i=0;i<a.length();i++){JSONObject v=Core.publicUser(a.getJSONObject(i));authors.put(v.getString("uuid"),v);}for(int i=0;i<s.length();i++){JSONObject v=Core.publicScript(s.getJSONObject(i));scripts.put(v.getString("uuid"),v);}refreshed=o.optLong("refreshed");}catch(Exception ignored){}}
    private synchronized void writeCache(){try{JSONObject o=new JSONObject().put("account",cacheAccount).put("refreshed",refreshed).put("authors",new JSONArray(authors.values())).put("scripts",new JSONArray(scripts.values()));File tmp=new File(context.getFilesDir(),"public-catalog.tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));}if(!tmp.renameTo(new File(context.getFilesDir(),"public-catalog.json")))tmp.delete();}catch(Exception ignored){}}
}
